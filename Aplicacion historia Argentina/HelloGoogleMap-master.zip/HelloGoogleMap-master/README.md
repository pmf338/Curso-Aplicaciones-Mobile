# Hello Google Map

## Description
  This is a demo project of [cordova-plugin-googlemaps](https://github.com/mapsplugin/cordova-plugin-googlemaps).

## Tutorials
  - [Develop on your PC](https://github.com/mapsplugin/cordova-plugin-googlemaps-doc/blob/master/v2.3.0/hello-world/README.md)
  - [Develop on your Cloud build](https://github.com/mapsplugin/cordova-plugin-googlemaps-doc/blob/master/v2.3.0/hello-world-phonegap-build/README.md)

## Demo
  - [Browser version](https://mapsplugin.github.io/HelloGoogleMap/)
  - [Android APK file](https://raw.githubusercontent.com/mapsplugin/HelloGoogleMap/master/sample.apk)
